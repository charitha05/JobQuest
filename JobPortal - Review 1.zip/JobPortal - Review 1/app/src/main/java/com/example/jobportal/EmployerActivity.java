package com.example.jobportal;

public class EmployerActivity {
}
